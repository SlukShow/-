+++
date = "2017-05-27T20:38:56+02:00"
draft = false
title = "JAMstack Recipes"
layout = "index"
+++

# JAMstack Recipes

The best jam recipes served by JAMstack, Headless CMS and Serverless technology.