---
date: 2017-06-24T19:05:11.973Z
title: Strawberry Jam
layout: recipe
description: Jam made of strawberries tastes fantastic.
image:
  text: Strawberries
  url: /images/uploads/strawberries.jpg
ingredients:
  - ingredient:
      amount: '5'
      name: sugar
      unit: dl
  - ingredient:
      amount: '2'
      name: strawberries
      unit: l
---
## Method

1. Clean and rinse the strawberries. Vary berries and sugar in a saucepan and heat slowly.
2. Boil on low heat without lid, about 15 minutes. Shake the pot occasionally so that berries and sugar are mixed and the jam is heated, but do not touch. Skim.
3. Leave to rest for about 15 minutes, stirring occasionally. Pour the batter on clean, warm cans and put on lid. Store in the fridge.
