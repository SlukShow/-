---
date: 2017-06-24T18:57:47.422Z
title: Lingonberry Jam
layout: recipe
description: Jam made of lingonberries tastes great.
image:
  text: Lingonberries
  url: /images/uploads/lingonberries.jpg
ingredients:
  - ingredient:
      amount: '2'
      name: water
      unit: dl
  - ingredient:
      amount: '0.5'
      name: sugar
      unit: kg
  - ingredient:
      amount: '1'
      name: lingonberries
      unit: kg
---
## Method

1. Boil berries and water for 15-20 minutes.
2. Add sugar and stir until sugar has melted. Boil another 5 min.
3. Foam and sprinkle the jam into cans.
