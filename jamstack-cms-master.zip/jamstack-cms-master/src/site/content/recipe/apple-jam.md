---
date: 2017-06-24T18:38:50.121Z
title: Apple Jam
layout: recipe
description: Jam made of apples tastes awesome.
image:
  text: Apples
  url: /images/uploads/apples.jpg
ingredients:
  - ingredient:
      amount: '1'
      name: apples
      unit: kg
  - ingredient:
      amount: '0.5'
      name: water
      unit: dl
  - ingredient:
      amount: '5'
      name: sugar
      unit: dl
---
## Method

1. Scale and kernel of the apples. Place the peeled apple slices in a bowl of cold water so that they do not darken.
2. Lift the apples to a saucepan and add water. Boil on low heat and stir regularly. Stir the sugar when the apples soften (feel a test piece). Let boil again.
3. Mix the mash to the desired consistency with a rod mixer.
4. In the fridge the mash stays for 1-2 weeks. In freezer it will last up to a year.

